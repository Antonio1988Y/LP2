﻿namespace Ptriangulo1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.valorA = new System.Windows.Forms.TextBox();
            this.valorC = new System.Windows.Forms.TextBox();
            this.valorB = new System.Windows.Forms.TextBox();
            this.txtValA = new System.Windows.Forms.Label();
            this.txtValB = new System.Windows.Forms.Label();
            this.txtValC = new System.Windows.Forms.Label();
            this.btnvalidador = new System.Windows.Forms.Button();
            this.btbsair = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            this.SuspendLayout();
            // 
            // valorA
            // 
            this.valorA.Location = new System.Drawing.Point(559, 124);
            this.valorA.Name = "valorA";
            this.valorA.Size = new System.Drawing.Size(227, 26);
            this.valorA.TabIndex = 0;
            this.valorA.Validated += new System.EventHandler(this.Txtnum1_Validated);
            // 
            // valorC
            // 
            this.valorC.Location = new System.Drawing.Point(559, 352);
            this.valorC.Name = "valorC";
            this.valorC.Size = new System.Drawing.Size(227, 26);
            this.valorC.TabIndex = 1;
            this.valorC.Validated += new System.EventHandler(this.Txtnum3_Validated);
            // 
            // valorB
            // 
            this.valorB.Location = new System.Drawing.Point(559, 245);
            this.valorB.Name = "valorB";
            this.valorB.Size = new System.Drawing.Size(227, 26);
            this.valorB.TabIndex = 2;
            this.valorB.Validated += new System.EventHandler(this.Txtnum2_Validated);
            // 
            // txtValA
            // 
            this.txtValA.AutoSize = true;
            this.txtValA.Location = new System.Drawing.Point(362, 124);
            this.txtValA.Name = "txtValA";
            this.txtValA.Size = new System.Drawing.Size(93, 20);
            this.txtValA.TabIndex = 3;
            this.txtValA.Text = "NUMERO 1";
            // 
            // txtValB
            // 
            this.txtValB.AutoSize = true;
            this.txtValB.Location = new System.Drawing.Point(362, 245);
            this.txtValB.Name = "txtValB";
            this.txtValB.Size = new System.Drawing.Size(93, 20);
            this.txtValB.TabIndex = 4;
            this.txtValB.Text = "NUMERO 2";
            // 
            // txtValC
            // 
            this.txtValC.AutoSize = true;
            this.txtValC.Location = new System.Drawing.Point(362, 358);
            this.txtValC.Name = "txtValC";
            this.txtValC.Size = new System.Drawing.Size(93, 20);
            this.txtValC.TabIndex = 5;
            this.txtValC.Text = "NUMERO 3";
            // 
            // btnvalidador
            // 
            this.btnvalidador.Location = new System.Drawing.Point(409, 510);
            this.btnvalidador.Name = "btnvalidador";
            this.btnvalidador.Size = new System.Drawing.Size(340, 88);
            this.btnvalidador.TabIndex = 6;
            this.btnvalidador.Text = "VALIDADOR";
            this.btnvalidador.UseVisualStyleBackColor = true;
            this.btnvalidador.Validated += new System.EventHandler(this.Btnvalidador_Validated);
            // 
            // btbsair
            // 
            this.btbsair.Location = new System.Drawing.Point(847, 510);
            this.btbsair.Name = "btbsair";
            this.btbsair.Size = new System.Drawing.Size(261, 87);
            this.btbsair.TabIndex = 7;
            this.btbsair.Text = "Sair";
            this.btbsair.UseVisualStyleBackColor = true;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1270, 676);
            this.Controls.Add(this.btbsair);
            this.Controls.Add(this.btnvalidador);
            this.Controls.Add(this.txtValC);
            this.Controls.Add(this.txtValB);
            this.Controls.Add(this.txtValA);
            this.Controls.Add(this.valorB);
            this.Controls.Add(this.valorC);
            this.Controls.Add(this.valorA);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox valorA;
        private System.Windows.Forms.TextBox valorC;
        private System.Windows.Forms.TextBox valorB;
        private System.Windows.Forms.Label txtValA;
        private System.Windows.Forms.Label txtValB;
        private System.Windows.Forms.Label txtValC;
        private System.Windows.Forms.Button btnvalidador;
        private System.Windows.Forms.Button btbsair;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
    }
}

