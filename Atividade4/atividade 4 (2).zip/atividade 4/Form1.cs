﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Txtnum1_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(this.valorA, " ");
            double valorA;
            if (!double.TryParse(this.valorA.Text, out valorA))
            {
                errorProvider1.SetError(this.valorA, "Valor de A invalido");
            }
        }

        private void Txtnum2_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(this.valorB, " ");
            double valorB;
            if (!double.TryParse(this.valorB.Text, out valorB))
            {
                errorProvider2.SetError(this.valorB, "Valor de B invalido");
            }
        }

        private void Txtnum3_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(this.valorC, " ");
            double valorC;
            if (!double.TryParse(this.valorC.Text, out valorC))
            {
                errorProvider3.SetError(this.valorC, "Valor de C invalido");
            }
        }

        private void Btnvalidador_Validated(object sender, EventArgs e)
        {
            double valorA = 0, valorB = 0, valorC = 0;

            if (!double.TryParse(txtValA.Text, out valorA) ||
                !double.TryParse(txtValB.Text, out valorB) ||
                !double.TryParse(txtValC.Text, out valorC))

            {
                MessageBox.Show("valores devem ser númerico");
            }
            else
            {
                if (valorA < (valorB + valorC) && valorA >
                    Math.Abs(valorB - valorC) && valorB < (valorA + valorC)
                    && valorB > Math.Abs(valorA - valorC)
                    && valorC > Math.Abs(valorA - valorB))
                {
                    if (valorA == valorB && valorB == valorC)
                        MessageBox.Show($"os valores {valorA}, {valorB} e {valorC} formam um triangulo equilatero");
                    else
                    {
                        if (valorA == valorB || valorA == valorC || valorC == valorB)
                            MessageBox.Show($"os valores {valorA}, {valorB} e {valorC} formam um triangulo Isoceles");
                        else
                            MessageBox.Show($"Os valores {valorA} , {valorB} e {valorC} Formam um triangulo escaleno");
                    }
                }
                else
                    MessageBox.Show($"os valores {valorA}, {valorB} e {valorC} Não formam um triangulo");


            }
        }
    }
}