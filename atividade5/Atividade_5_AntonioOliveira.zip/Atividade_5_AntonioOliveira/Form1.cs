﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_5_AntonioOliveira
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnverificadesconto_Click(object sender, EventArgs e)
        {
            /////codigo
            double SalarioBruto, SalarioLiquido, SalarioFamilia, descontoINSS, descontoIRPF;
            int Filhos;

            Filhos = int.Parse(numerodefilhos.Text);
            SalarioBruto = double.Parse(mskbxsalariobruto.Text);

            if (SalarioBruto <= 800.47)
            {
                mskbxAliqINSS.Text = "7,65%";
                descontoINSS = 0.0765 * SalarioBruto;
            }
            else if (SalarioBruto <= 1050)
            {
                mskbxAliqINSS.Text = "8,65%";
                descontoINSS = 0.0865 * SalarioBruto;
            }
            else if (SalarioBruto <= 1400.77)
            {
                mskbxAliqINSS.Text = "9%";
                descontoINSS = 0.09 * SalarioBruto;
            }
            else if (SalarioBruto <= 2801.56)
            {
                mskbxAliqINSS.Text = "11%";
                descontoINSS = 0.11 * SalarioBruto;
            }
            else
            { 
            mskbxAliqINSS.Text = "Teto";
            descontoINSS = 308.17;
            }

            if(SalarioBruto <= 1257.12)
            {
                mskbxAliqIRPF.Text = "ISENTO";
                descontoIRPF = 0;
            }
            else if ( SalarioBruto <= 2512.08)
            {
                mskbxAliqIRPF.Text = "15%";
                descontoIRPF = 0.15 * SalarioBruto;
            }
            else
            {
                mskbxAliqIRPF.Text = "27,5%";
                descontoIRPF = 0.275 * SalarioBruto;
            }
            if (SalarioBruto <= 435.52)
            {
                
                SalarioFamilia = Filhos * 22.33;
                            }
            else if( SalarioBruto <= 654.61)
            {
               SalarioFamilia = Filhos * 15.74;
            }
            else
            {
               SalarioFamilia = 0;
            }

            mskbxDescontoINSS.Text = descontoINSS.ToString();
            mskbxDescontoIRPF.Text = descontoIRPF.ToString();
            mskbxSalrioFamilia.Text = SalarioFamilia.ToString();
            SalarioLiquido = SalarioBruto - descontoINSS - descontoIRPF + SalarioFamilia;
            mskbxSalarioLiquido.Text = SalarioLiquido.ToString();
            //////codigo

        }
    }
}
