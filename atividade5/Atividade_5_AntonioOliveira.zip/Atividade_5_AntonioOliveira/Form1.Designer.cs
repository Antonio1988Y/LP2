﻿
namespace Atividade_5_AntonioOliveira
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblnomefuncionario = new System.Windows.Forms.Label();
            this.lblDescontoINSS = new System.Windows.Forms.Label();
            this.lblDescontoIRPF = new System.Windows.Forms.Label();
            this.lblSalarioLiquido = new System.Windows.Forms.Label();
            this.lblSalariofamilia = new System.Windows.Forms.Label();
            this.lblAliqIRPF = new System.Windows.Forms.Label();
            this.lblalqinss = new System.Windows.Forms.Label();
            this.lblnumerodefilhos = new System.Windows.Forms.Label();
            this.lblsalariobruto = new System.Windows.Forms.Label();
            this.mskbxnomefuncionario = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalarioLiquido = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalrioFamilia = new System.Windows.Forms.MaskedTextBox();
            this.mskbxAliqIRPF = new System.Windows.Forms.MaskedTextBox();
            this.mskbxAliqINSS = new System.Windows.Forms.MaskedTextBox();
            this.mskbxsalariobruto = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescontoIRPF = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescontoINSS = new System.Windows.Forms.MaskedTextBox();
            this.numerodefilhos = new System.Windows.Forms.NumericUpDown();
            this.btnverificadesconto = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numerodefilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblnomefuncionario
            // 
            this.lblnomefuncionario.AutoSize = true;
            this.lblnomefuncionario.Location = new System.Drawing.Point(33, 46);
            this.lblnomefuncionario.Name = "lblnomefuncionario";
            this.lblnomefuncionario.Size = new System.Drawing.Size(93, 13);
            this.lblnomefuncionario.TabIndex = 0;
            this.lblnomefuncionario.Text = "Nome Funcionário";
            // 
            // lblDescontoINSS
            // 
            this.lblDescontoINSS.AutoSize = true;
            this.lblDescontoINSS.Location = new System.Drawing.Point(446, 287);
            this.lblDescontoINSS.Name = "lblDescontoINSS";
            this.lblDescontoINSS.Size = new System.Drawing.Size(81, 13);
            this.lblDescontoINSS.TabIndex = 1;
            this.lblDescontoINSS.Text = "Desconto INSS";
            // 
            // lblDescontoIRPF
            // 
            this.lblDescontoIRPF.AutoSize = true;
            this.lblDescontoIRPF.Location = new System.Drawing.Point(446, 324);
            this.lblDescontoIRPF.Name = "lblDescontoIRPF";
            this.lblDescontoIRPF.Size = new System.Drawing.Size(80, 13);
            this.lblDescontoIRPF.TabIndex = 2;
            this.lblDescontoIRPF.Text = "Desconto IRPF";
            // 
            // lblSalarioLiquido
            // 
            this.lblSalarioLiquido.AutoSize = true;
            this.lblSalarioLiquido.Location = new System.Drawing.Point(33, 406);
            this.lblSalarioLiquido.Name = "lblSalarioLiquido";
            this.lblSalarioLiquido.Size = new System.Drawing.Size(76, 13);
            this.lblSalarioLiquido.TabIndex = 3;
            this.lblSalarioLiquido.Text = "Salario Liquido";
            // 
            // lblSalariofamilia
            // 
            this.lblSalariofamilia.AutoSize = true;
            this.lblSalariofamilia.Location = new System.Drawing.Point(33, 366);
            this.lblSalariofamilia.Name = "lblSalariofamilia";
            this.lblSalariofamilia.Size = new System.Drawing.Size(76, 13);
            this.lblSalariofamilia.TabIndex = 4;
            this.lblSalariofamilia.Text = "Salario Família";
            // 
            // lblAliqIRPF
            // 
            this.lblAliqIRPF.AutoSize = true;
            this.lblAliqIRPF.Location = new System.Drawing.Point(33, 324);
            this.lblAliqIRPF.Name = "lblAliqIRPF";
            this.lblAliqIRPF.Size = new System.Drawing.Size(72, 13);
            this.lblAliqIRPF.TabIndex = 5;
            this.lblAliqIRPF.Text = "Aliquota IRPF";
            // 
            // lblalqinss
            // 
            this.lblalqinss.AutoSize = true;
            this.lblalqinss.Location = new System.Drawing.Point(33, 287);
            this.lblalqinss.Name = "lblalqinss";
            this.lblalqinss.Size = new System.Drawing.Size(73, 13);
            this.lblalqinss.TabIndex = 6;
            this.lblalqinss.Text = "Aliquota INSS";
            // 
            // lblnumerodefilhos
            // 
            this.lblnumerodefilhos.AutoSize = true;
            this.lblnumerodefilhos.Location = new System.Drawing.Point(33, 158);
            this.lblnumerodefilhos.Name = "lblnumerodefilhos";
            this.lblnumerodefilhos.Size = new System.Drawing.Size(86, 13);
            this.lblnumerodefilhos.TabIndex = 7;
            this.lblnumerodefilhos.Text = "Numero de filhos";
            // 
            // lblsalariobruto
            // 
            this.lblsalariobruto.AutoSize = true;
            this.lblsalariobruto.Location = new System.Drawing.Point(33, 92);
            this.lblsalariobruto.Name = "lblsalariobruto";
            this.lblsalariobruto.Size = new System.Drawing.Size(67, 13);
            this.lblsalariobruto.TabIndex = 8;
            this.lblsalariobruto.Text = "Salario Bruto";
            // 
            // mskbxnomefuncionario
            // 
            this.mskbxnomefuncionario.Location = new System.Drawing.Point(135, 46);
            this.mskbxnomefuncionario.Name = "mskbxnomefuncionario";
            this.mskbxnomefuncionario.Size = new System.Drawing.Size(439, 20);
            this.mskbxnomefuncionario.TabIndex = 9;
            // 
            // mskbxSalarioLiquido
            // 
            this.mskbxSalarioLiquido.Enabled = false;
            this.mskbxSalarioLiquido.Location = new System.Drawing.Point(135, 406);
            this.mskbxSalarioLiquido.Name = "mskbxSalarioLiquido";
            this.mskbxSalarioLiquido.Size = new System.Drawing.Size(159, 20);
            this.mskbxSalarioLiquido.TabIndex = 10;
            // 
            // mskbxSalrioFamilia
            // 
            this.mskbxSalrioFamilia.Enabled = false;
            this.mskbxSalrioFamilia.Location = new System.Drawing.Point(135, 359);
            this.mskbxSalrioFamilia.Name = "mskbxSalrioFamilia";
            this.mskbxSalrioFamilia.Size = new System.Drawing.Size(159, 20);
            this.mskbxSalrioFamilia.TabIndex = 11;
            // 
            // mskbxAliqIRPF
            // 
            this.mskbxAliqIRPF.Enabled = false;
            this.mskbxAliqIRPF.Location = new System.Drawing.Point(135, 324);
            this.mskbxAliqIRPF.Name = "mskbxAliqIRPF";
            this.mskbxAliqIRPF.Size = new System.Drawing.Size(159, 20);
            this.mskbxAliqIRPF.TabIndex = 12;
            // 
            // mskbxAliqINSS
            // 
            this.mskbxAliqINSS.Enabled = false;
            this.mskbxAliqINSS.Location = new System.Drawing.Point(135, 280);
            this.mskbxAliqINSS.Name = "mskbxAliqINSS";
            this.mskbxAliqINSS.Size = new System.Drawing.Size(159, 20);
            this.mskbxAliqINSS.TabIndex = 13;
            // 
            // mskbxsalariobruto
            // 
            this.mskbxsalariobruto.Location = new System.Drawing.Point(135, 92);
            this.mskbxsalariobruto.Name = "mskbxsalariobruto";
            this.mskbxsalariobruto.Size = new System.Drawing.Size(189, 20);
            this.mskbxsalariobruto.TabIndex = 14;
            // 
            // mskbxDescontoIRPF
            // 
            this.mskbxDescontoIRPF.Enabled = false;
            this.mskbxDescontoIRPF.Location = new System.Drawing.Point(532, 324);
            this.mskbxDescontoIRPF.Name = "mskbxDescontoIRPF";
            this.mskbxDescontoIRPF.Size = new System.Drawing.Size(150, 20);
            this.mskbxDescontoIRPF.TabIndex = 15;
            // 
            // mskbxDescontoINSS
            // 
            this.mskbxDescontoINSS.Enabled = false;
            this.mskbxDescontoINSS.Location = new System.Drawing.Point(532, 287);
            this.mskbxDescontoINSS.Name = "mskbxDescontoINSS";
            this.mskbxDescontoINSS.Size = new System.Drawing.Size(150, 20);
            this.mskbxDescontoINSS.TabIndex = 16;
            // 
            // numerodefilhos
            // 
            this.numerodefilhos.Location = new System.Drawing.Point(135, 156);
            this.numerodefilhos.Name = "numerodefilhos";
            this.numerodefilhos.Size = new System.Drawing.Size(120, 20);
            this.numerodefilhos.TabIndex = 17;
            // 
            // btnverificadesconto
            // 
            this.btnverificadesconto.Location = new System.Drawing.Point(135, 205);
            this.btnverificadesconto.Name = "btnverificadesconto";
            this.btnverificadesconto.Size = new System.Drawing.Size(159, 40);
            this.btnverificadesconto.TabIndex = 18;
            this.btnverificadesconto.Text = "Verifica Desconto";
            this.btnverificadesconto.UseVisualStyleBackColor = true;
            this.btnverificadesconto.Click += new System.EventHandler(this.btnverificadesconto_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnverificadesconto);
            this.Controls.Add(this.numerodefilhos);
            this.Controls.Add(this.mskbxDescontoINSS);
            this.Controls.Add(this.mskbxDescontoIRPF);
            this.Controls.Add(this.mskbxsalariobruto);
            this.Controls.Add(this.mskbxAliqINSS);
            this.Controls.Add(this.mskbxAliqIRPF);
            this.Controls.Add(this.mskbxSalrioFamilia);
            this.Controls.Add(this.mskbxSalarioLiquido);
            this.Controls.Add(this.mskbxnomefuncionario);
            this.Controls.Add(this.lblsalariobruto);
            this.Controls.Add(this.lblnumerodefilhos);
            this.Controls.Add(this.lblalqinss);
            this.Controls.Add(this.lblAliqIRPF);
            this.Controls.Add(this.lblSalariofamilia);
            this.Controls.Add(this.lblSalarioLiquido);
            this.Controls.Add(this.lblDescontoIRPF);
            this.Controls.Add(this.lblDescontoINSS);
            this.Controls.Add(this.lblnomefuncionario);
            this.Name = "Form1";
            this.Text = "Calcular Salario";
            ((System.ComponentModel.ISupportInitialize)(this.numerodefilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblnomefuncionario;
        private System.Windows.Forms.Label lblDescontoINSS;
        private System.Windows.Forms.Label lblDescontoIRPF;
        private System.Windows.Forms.Label lblSalarioLiquido;
        private System.Windows.Forms.Label lblSalariofamilia;
        private System.Windows.Forms.Label lblAliqIRPF;
        private System.Windows.Forms.Label lblalqinss;
        private System.Windows.Forms.Label lblnumerodefilhos;
        private System.Windows.Forms.Label lblsalariobruto;
        private System.Windows.Forms.MaskedTextBox mskbxnomefuncionario;
        private System.Windows.Forms.MaskedTextBox mskbxSalarioLiquido;
        private System.Windows.Forms.MaskedTextBox mskbxSalrioFamilia;
        private System.Windows.Forms.MaskedTextBox mskbxAliqIRPF;
        private System.Windows.Forms.MaskedTextBox mskbxAliqINSS;
        private System.Windows.Forms.MaskedTextBox mskbxsalariobruto;
        private System.Windows.Forms.MaskedTextBox mskbxDescontoIRPF;
        private System.Windows.Forms.MaskedTextBox mskbxDescontoINSS;
        private System.Windows.Forms.NumericUpDown numerodefilhos;
        private System.Windows.Forms.Button btnverificadesconto;
    }
}

